<template>
  <div class="all-box introduced-page">
        <div class="release-all">
            <span class="ralease release1" >发布需求</span>
            <span class="ralease release2">发布房源</span>
        </div>
        <div class="introduced-footer">
            <router-link class="cancel-intro  click-return" tag="i" to="/home"></router-link>
        </div>
    </div>
</template>
<script>

export default {
  name:'announce',
}
</script>
<style scoped>
@import '../assets/css/public.css';
@import '../assets/css/annInfo.css';
</style>
