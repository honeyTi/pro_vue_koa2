<template>
<div>
    <li class="tool">
        <i class="iconfont icon-ditie" style="font-size:23px;"></i>
        <span class="tool-name">地铁</span>
    </li>
</div>
</template>
<script>
export default {
  name:'subway',
  data(){
      return{
          popShow: false,
      }
  },
  methods:{
  }
}
</script>
<style>
@import '../../../assets/css/tools/tools.scss';
</style>

